//
//  CloudFoTests.h
//  CloudFoTests
//
//  Created by robin on 12-4-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CloudFoTests : SenTestCase

@end
