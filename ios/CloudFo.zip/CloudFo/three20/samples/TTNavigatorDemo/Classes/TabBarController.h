#import <Three20/Three20.h>

@interface TabBarController : UITabBarController {
}

@end
