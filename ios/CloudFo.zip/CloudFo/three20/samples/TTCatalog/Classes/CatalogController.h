#import <Three20/Three20.h>

@interface CatalogController : TTTableViewController
@end
