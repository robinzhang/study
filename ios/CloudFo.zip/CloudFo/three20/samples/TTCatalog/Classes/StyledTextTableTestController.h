#import <Three20/Three20.h>

@interface StyledTextTableTestController : TTTableViewController
@end
