
@interface SplitCatalogController : TTSplitViewController {
}

@end
