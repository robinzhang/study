#import <Three20/Three20.h>

@interface AppDelegate : NSObject <UIApplicationDelegate>

@end

