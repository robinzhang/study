#import <Three20/Three20.h>

@interface DownloadTestModel : TTURLRequestModel {
  NSString  *_downloadUrl;
}

@property (nonatomic, assign) NSString* downloadUrl;

@end

