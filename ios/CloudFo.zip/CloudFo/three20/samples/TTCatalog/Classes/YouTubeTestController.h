#import <Three20/Three20.h>

@interface YouTubeTestController : TTViewController {
  TTYouTubeView* youTubeView;
}

@end
