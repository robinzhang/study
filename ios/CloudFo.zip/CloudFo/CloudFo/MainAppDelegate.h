//
//  MainAppDelegate.h
//  CloudFo
//
//  Created by robin on 12-4-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Three20/Three20.h>

@interface MainAppDelegate : NSObject<UIApplicationDelegate,UIAlertViewDelegate>

- (void) loadNavigationSystem;
@end
