//
//  BookViewController.h
//  CloudFo
//
//  Created by robin on 12-4-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Three20/Three20.h>
#import "MyTableViewControler.h"

@interface BookViewController : MyTableViewControler<TTTabDelegate>
{
}
@end
